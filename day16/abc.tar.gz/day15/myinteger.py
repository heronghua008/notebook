# myinteger.py


# 此示例示意用生成函数生成一系列从0开始的整数

def myinteger(n):
    i = 0
    while i < n:
        yield i
        i += 1


for x in myinteger(100000000000000000000000):
    print(x)



