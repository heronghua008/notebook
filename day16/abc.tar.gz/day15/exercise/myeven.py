# 练习:
#   写一个生成器函数myeven(start, stop)，用来生成从start开始，到stop结束区间内的一系列偶数

#   def myeven(start, stop):  # 不包含stop
#       .... 此处自己实现

#   it = iter(myeven(5, 10))
#   print(next(it))  # 6
#   print(next(it))  # 8

#   evens = list(myeven(10, 20))
#   print(evens)  # [10, 12, 14, 16, 18]
#   for x in myeven(21, 30):
#       print(x)  # 22 24 26 28


def myeven(start, stop):  # 不包含stop
    i = start
    while i < stop:
        if i % 2 == 0:
            yield i
        i += 1


# def myeven(start, stop):  # 不包含stop
#     i = start
#     if i % 2 == 1:
#         i += 1
#     while i < stop:
#         if i % 2 == 0:
#             yield i
#         i += 2

# def myeven(start, stop):  # 不包含stop
#     i = start
#     if i % 2 == 1:
#         i += 1
#     for x in range(i, stop, 2):
#         yield x


# def myeven(start, stop):  # 不包含stop
#     i = start
#     if i % 2 == 1:
#         i += 1
#     return range(i, stop, 2)


it = iter(myeven(5, 10))
print(next(it))  # 6
print(next(it))  # 8

evens = list(myeven(10, 20))
print(evens)  # [10, 12, 14, 16, 18]
for x in myeven(21, 30):
    print(x)  # 22 24 26 28

L = [x ** 2 for x in myeven(10, 20)]
print(L)