# 练习:
#   有一个集合:
#     xiyou = {'唐僧', '悟空', '八戒','沙僧'}
#     用for 语句来遍历所有元素如下:
#       for x in xiyou:
#           print(x)
#       else:
#           print("遍历结束")
#     请将上面的for语句改写为while语句及迭代器实现


xiyou = {'唐僧', '悟空', '八戒', '沙僧'}
for x in xiyou:
    print(x)
else:
    print("遍历结束")

print('-----------------')
it = iter(xiyou)
while True:
    try:
        x = next(it)
        print(x)
    except StopIteration:
        print("遍历结束")
        break

print("==================")
try:
    it = iter(xiyou)
    while True:
        x = next(it)
        print(x)
except StopIteration:
    print("遍历结束")









