# yield.py


# 此示例示意函数yield 语句的生成器函数定义方式和用法

def myyield():
    '''此函数因为含有yield语句，所以是生成器函数'''
    print("即将生成1")
    yield 1
    print("即将生成3")
    yield 3
    print("即将生成5")
    yield 5
    print("即将生成7")
    yield 7
    print("生成结束")

gen = myyield()  # gen 绑定是的生成器,生成器是可迭代对 象
it = iter(gen)

# next(it)开始执行生成器函数的语句，直到遇见yield语句为止
x = next(it)
print(x)

# for x in gen:
#     print(x)  # 1 3 5 7


