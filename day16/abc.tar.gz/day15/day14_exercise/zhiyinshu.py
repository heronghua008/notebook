# 2. 分解质因数,输入一个正整数，分解质因数
#    如输入: 90 则打印:
#       90 = 2*3*3*5
#    (质因数是指最小能被原数整除的素数(不包含1))

def is_prime(x):
    if x < 2:
        return False
    for i in range(2, x):
        if x % i == 0:
            return False
    # else:
    #     return True
    return True


def get_yinshu_list(n):
    '''用循环实现'''
    L = [] # 用来存放所有的质因数
    x = n  # x代表未分解的数
    while not is_prime(x):  # 当x不是素数时开始循环
        for i in range(2, x):
            if x % i == 0 and is_prime(i):  # 被整除,i是质因数
                L.append(i)
                x = int(x / i)
                break
    L.append(x)
    return L



n = int(input("请输入一个正整数: "))

# print(get_yinshu_list(n))
yinshu = get_yinshu_list(n)
s = '*'.join([str(x) for x in yinshu])
print("%d = %s" % (n, s))






